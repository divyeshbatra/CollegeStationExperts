﻿CStat Corps Experts v0.5

**************************************************************************
SUMMARY
**************************************************************************
Technology is a compendium of various techniques and skills which has made our lives simpler by reducing
the time frame. On the flip side, as technology is growing day-by-day and people are moving across
continents in search for better opportunities, there is an interspersed gamut of skillsets within any
organization. It becomes increasingly difficult foremployees to look beyond their daily job responsibilities
and connect intellectually with their counterparts. “CStat Corps Experts” is a comprehensive search and
digital recommendation tool build for a hypothetical organization “CStat Corps” that facilitates its
employees to search for subject-matter experts within the organization and digitally recommend each
other. This not only promotes a collaborative environment but also enables an organization to keep a
track of all the skill sets that its workforce possesses. For instance, HR department can look out for subject-
matter experts with the use of this tool and organize seminars/ trainings without relying on any third party
vendor, thereby, providing a cost-effective solution. Additionally, senior leadership can keep a track of
organization-wide skills and devise strategies for future growth. The unique selling point for CStat Corps
Experts is: Search, Recommend and Brand.

**************************************************************************
CHANGES
**************************************************************************
Version 0.5
-- Final Release
-- Implementation of view Recommendations and finding average ratings for the employee 
-- Code refinement with respect to all additional validations for invalid inputs
-- More modularity from code perspective
-- Code as per Production quality

Version 0.4
-- release candidate
-- Implementation of login credentials and edit profile (based on different criterias) features 
-- Implementation of searching an employee based on his ID feature
-- Code refinement with respect to all additional validations for invalid inputs
-- Code has been made made modular by segregating it into different classes and methods

Version 0.3
-- beta release
-- Implementation of Search and recommendation functions with additional validation for positive or negative number inputs other than 1,2 or 3
   to search employees based on criteria  
-- Update rating and recommendations given by the recommender based on employee ID.       

Version 0.2
-- alpha release
-- completed first pass of primary use case (Search employees based on Skill, Interest and Designation)
-- naive implementation of Searching system (Based on criteria chosen from 3 categories, search employees as per input value)

Version 0.1 
-- Proof of architecture

**************************************************************************
SETUP
**************************************************************************
1. Unzip the Team4-finalrelease.zip on your eclipse workspace.
2. Import Gradle project through eclipse from local workspace folder.(Data folder having all csv data files is present in project root folder)
3. Provide login credentials as follows:
	Email: mary.athy@cstatcorps.com
	Pwd  : MaryAthy@2017
Anything other than correct username and password will give an error message as "Invalid credentails, Please try again" and you will be prompted to re-enter your credentials.
If logged in using correct credentials, the system will display the message "You have been logged in successfully."

Do you want to Recommend, Search, Edit profile, View Recommendations or sign out?
If you press any other option (alphabet or number) apart from the asked once, system will show "Invalid input, please select the correct option"

4. Provide "S" for search ("S" or "s" both will work)
You will be asked to enter the search criteria
->Enter 4 for Employee ID (wrong output will display "Invalid selection, please make the correct selection")
->Try 7 as Employee ID
All the details of the employee will be displayed (name, email, designation, contact, skills, interests & average rating)
NOTE THE AVERAGE RATING FOR THIS EMPLOYEE IS 4.50 (We will give one more recommendation to this employee to see how it affects average rating and whether new recommendation is given is saved in database)

5. Now Press "r" or "R" to give Recommendation to this employee
->Enter EmployeeID as 7
->Press Y or y to continue recommending
->Try entering Rating as 2
->Write recommedation as "An average knowledge in SQL"
The system will tell that recommendation has been saved in database.
(NEXT we will check whether our recommendation is reflected or not)

6. Enter V or v to View Recommendation
->Enter EmployeeID as 7
You can see the change in average rating from 4.5 to 3.67 and can also check the Ratings & Recommendations given by different people including your entry.
->Press n or N to discontinue viewing recommendations

7. Enter Exit or exit or EXIT to log out. This will terminate the program as well. 


Other Notes- 
1. There are 3 warning messages related to slf4j dependency. The warning bears no impact on our project and can be safely ignored.
2. You can also try other different options based on your choice.

